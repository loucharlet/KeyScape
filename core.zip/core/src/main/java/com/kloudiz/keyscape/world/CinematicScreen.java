package com.kloudiz.keyscape.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.video.VideoPlayer;
import com.badlogic.gdx.video.VideoPlayerCreator;
import com.kloudiz.keyscape.HomeScreen;
import com.kloudiz.keyscape.Main;

import java.io.FileNotFoundException;

public class CinematicScreen implements Screen {
    
    public enum CinematicType {
        INTRO,
        OUTRO
    }
    
    private Main game;
    private VideoPlayer videoPlayer;
    private SpriteBatch batch;
    private BitmapFont font;
    private boolean videoFinished = false;
    private CinematicType type;
    
    private static final String INTRO_PATH = "assets/film/CineIntro.mp4";
    private static final String OUTRO_PATH = "assets/film/CineOutro.mp4";
    
    public CinematicScreen(Main game, CinematicType type) {
        this.game = game;
        this.type = type;
        this.batch = new SpriteBatch();
        this.font = new BitmapFont();
        this.font.setColor(Color.WHITE);
        this.font.getData().setScale(0.8f);
    }
    
    @Override
    public void show() {
        try {
            videoPlayer = VideoPlayerCreator.createVideoPlayer();
            
            String videoPath = (type == CinematicType.INTRO) ? INTRO_PATH : OUTRO_PATH;
            
            videoPlayer.play(Gdx.files.internal(videoPath));
            
            videoPlayer.setOnCompletionListener(file -> {
                videoFinished = true;
                System.out.println("🎬 Cinématique terminée !");
            });
            
            System.out.println("🎬 Lecture de la cinématique : " + videoPath);
            
        } catch (FileNotFoundException e) {
            System.err.println("❌ Erreur : Impossible de charger la vidéo");
            e.printStackTrace();
            videoFinished = true;
        } catch (Exception e) {
            System.err.println("❌ Erreur vidéo : " + e.getMessage());
            e.printStackTrace();
            videoFinished = true;
        }
    }
    
    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        // Vérifie si on skip avec ESPACE ou ECHAP
        if (Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.SPACE) || 
            Gdx.input.isKeyJustPressed(com.badlogic.gdx.Input.Keys.ESCAPE)) {
            skipCinematic();
            return;
        }
        
        // Si la vidéo est terminée, on passe à l'écran suivant
        if (videoFinished) {
            goToNextScreen();
            return;
        }
        
        // Mise à jour et rendu de la vidéo
        if (videoPlayer != null) {
            videoPlayer.update();
            
            batch.begin();
            
            // Affiche la vidéo
            if (videoPlayer.getTexture() != null) {
                float videoWidth = videoPlayer.getTexture().getWidth();
                float videoHeight = videoPlayer.getTexture().getHeight();
                
                // Calcul pour centrer la vidéo tout en gardant le ratio
                float screenWidth = Gdx.graphics.getWidth();
                float screenHeight = Gdx.graphics.getHeight();
                
                float scale = Math.min(screenWidth / videoWidth, screenHeight / videoHeight);
                float scaledWidth = videoWidth * scale;
                float scaledHeight = videoHeight * scale;
                
                float x = (screenWidth - scaledWidth) / 2;
                float y = (screenHeight - scaledHeight) / 2;
                
                batch.draw(videoPlayer.getTexture(), x, y, scaledWidth, scaledHeight);
            }
            
            // Bouton skip discret en bas à droite
            font.setColor(new Color(1, 1, 1, 0.6f));
            font.draw(batch, "ESPACE pour passer", 
                     Gdx.graphics.getWidth() - 150, 
                     30);
            
            batch.end();
        }
    }
    
    private void skipCinematic() {
        System.out.println("⏭️ Cinématique passée");
        if (videoPlayer != null) {
            videoPlayer.stop();
        }
        goToNextScreen();
    }
    
    private void goToNextScreen() {
        if (type == CinematicType.INTRO) {
            // Après l'intro, on va au menu principal
            game.setScreen(new HomeScreen(game));
        } else {
            // Après l'outro, on retourne au menu principal aussi
            game.setScreen(new HomeScreen(game));
        }
    }
    
    @Override
    public void resize(int width, int height) {}
    
    @Override
    public void pause() {
        if (videoPlayer != null) {
            videoPlayer.pause();
        }
    }
    
    @Override
    public void resume() {
        if (videoPlayer != null) {
            videoPlayer.resume();
        }
    }
    
    @Override
    public void hide() {
        dispose();
    }
    
    @Override
    public void dispose() {
        if (videoPlayer != null) {
            videoPlayer.dispose();
        }
        if (batch != null) {
            batch.dispose();
        }
        if (font != null) {
            font.dispose();
        }
    }
}
