package com.kloudiz.keyscape;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

/**
 * Classe utilitaire pour créer des styles de boutons
 */
public class ButtonStyleFactory {
    
    /**
     * Crée un style de bouton avec des couleurs personnalisées
     * @param width Largeur du bouton
     * @param height Hauteur du bouton
     * @param normalColor Couleur normale
     * @param hoverColor Couleur au survol
     * @param pressedColor Couleur quand pressé
     * @return Le style créé
     */
    public static TextButton.TextButtonStyle createColoredButtonStyle(
            int width, int height,
            Color normalColor, Color hoverColor, Color pressedColor) {
        
        TextButton.TextButtonStyle style = new TextButton.TextButtonStyle();
        
        // Création des textures pour les différents états
        style.up = new TextureRegionDrawable(createRoundedRectTexture(width, height, normalColor));
        style.over = new TextureRegionDrawable(createRoundedRectTexture(width, height, hoverColor));
        style.down = new TextureRegionDrawable(createRoundedRectTexture(width, height, pressedColor));
        
        // Police (tu peux charger une police personnalisée)
        style.font = new BitmapFont(); // Police par défaut de LibGDX
        style.fontColor = Color.WHITE;
        
        return style;
    }
    
    /**
     * Crée un style de bouton "Jouer" par défaut
     */
    public static TextButton.TextButtonStyle createPlayButtonStyle() {
        return createColoredButtonStyle(
            200, 60,
            new Color(0.2f, 0.6f, 0.2f, 1),  // Vert normal
            new Color(0.3f, 0.7f, 0.3f, 1),  // Vert clair au survol
            new Color(0.15f, 0.5f, 0.15f, 1) // Vert foncé quand pressé
        );
    }
    
    /**
     * Crée une texture rectangulaire arrondie
     */
    private static TextureRegion createRoundedRectTexture(int width, int height, Color color) {
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setColor(color);
        pixmap.fillRectangle(0, 0, width, height);
        
        // Ajout d'une bordure légèrement plus foncée
        pixmap.setColor(color.r * 0.7f, color.g * 0.7f, color.b * 0.7f, 1);
        pixmap.drawRectangle(0, 0, width, height);
        pixmap.drawRectangle(1, 1, width - 2, height - 2);
        
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        
        return new TextureRegion(texture);
    }
    
    /**
     * Crée une texture simple de couleur unie
     */
    public static Texture createColorTexture(int width, int height, Color color) {
        Pixmap pixmap = new Pixmap(width, height, Pixmap.Format.RGBA8888);
        pixmap.setColor(color);
        pixmap.fill();
        Texture texture = new Texture(pixmap);
        pixmap.dispose();
        return texture;
    }
}
